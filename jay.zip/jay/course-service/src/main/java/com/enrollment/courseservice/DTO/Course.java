// com.enrollment.courseservice.model.Course.java
package com.enrollment.courseservice.DTO;

import com.fasterxml.jackson.annotation.JsonBackReference;


public class Course {

    private Long id;
    private String title;
    private String description;
    private Category category;

    // Default constructor
    public Course() {}

    // All-args constructor
    public Course(Long id, String title, String description, Category category) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.category = category;
    }

    //TODO: create the Getters & Setters

    // Debug-friendly output
    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
