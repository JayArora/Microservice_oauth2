package com.enrollment.courseservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.enrollment.courseservice.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    Optional<Category> findByName(String name);
    
}

