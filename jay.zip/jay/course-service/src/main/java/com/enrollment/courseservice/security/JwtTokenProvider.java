package com.enrollment.courseservice.security;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.crypto.SecretKey;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtTokenProvider {

    private static final Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);

    @Value("${jwt.secret:YOUR_SUPER_SECRET_KEY_THAT_IS_AT_LEAST_256_BITS_LONG}")
    private String jwtSecret;

    @Value("${jwt.expiration-ms:3600000}") // Default 1 hour
    private long jwtExpirationInMs;

    private SecretKey signingKey;

    @PostConstruct
    protected void init() {
        // In 0.13.0, you must generate a typed SecretKey using Keys utility
        byte[] keyBytes = jwtSecret.getBytes(StandardCharsets.UTF_8);
        this.signingKey = Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * Generate a compact JWT token string using custom identity parameters.
     */
    public String generateToken(String username, String roles) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + jwtExpirationInMs);

        // Modern 0.13.0 Fluent API (No "set" prefixes, no explicit SignatureAlgorithm needed)
        return Jwts.builder()
                .setSubject(username)
                .claim("roles", roles) 
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(SignatureAlgorithm.HS512, signingKey) // The algorithm is automatically derived from the key strength
                .compact();
    }

    /**
     * Extract the username from a verified token string.
     */
    public String getUsernameFromToken(String token) {
        // 1. Jwts.parser() returns a JwtParserBuilder
        // 2. Call .verifyWith(signingKey) on the builder
        // 3. Call .build() to produce a thread-safe JwtParser instance
        // 4. Finally, call .parseSignedClaims(token) on that parser instance
        Claims claims = Jwts.parser()
                .verifyWith(signingKey) 
                .build()                
                .parseSignedClaims(token)
                .getPayload();          

        return claims.getSubject();
    }

    public boolean validateToken(String token) {
        try {
            // Apply the same builder chain rules for verification blocks
            Jwts.parser()
                .verifyWith(signingKey)
                .build()
                .parseSignedClaims(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            logger.error("JWT Validation failed: {}", e.getMessage());
        }
        return false;
    }
}