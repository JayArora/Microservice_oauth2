package com.enrollment.courseservice.controller;

import com.enrollment.courseservice.entity.Course;
import com.enrollment.courseservice.service.CourseService;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    private static final Logger logger = LoggerFactory.getLogger(CourseController.class);

    @Autowired
    private CourseService courseService;

    /**
     * Handle HTTP POST to create a new course.
     * - Log the incoming course creation request with course title.
     * - Call service to create the course.
     * - Log a message after successful course creation.
     * - Return HTTP 201 (Created) with the created course in response.
     */
    @PostMapping
    public ResponseEntity<Course> createCourse(@Valid @RequestBody Course course) {
        logger.info("Received request to create course: {}", course.getTitle());
        Course createdCourse = courseService.createCourse(course);
        logger.info("Course created successfully");
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCourse);
    }

    /**
     * Handle HTTP GET to fetch all courses.
     * - Log the request to fetch all courses.
     * - Call service to retrieve all courses.
     * - If no courses found:
     *   - Log a warning.
     *   - Return 404 with message: "No courses found"
     * - Else:
     *   - Log how many courses were found.
     *   - Return HTTP 200 with list of courses.
     */
    @GetMapping
    public ResponseEntity<?> getAllCourses() {
        logger.info("GET /api/courses - Fetching all courses");
        List<Course> courses = courseService.getAllCourses();
        
        if (courses == null || courses.isEmpty()) {
            logger.warn("No courses found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No courses found");
        }
        
        logger.info("Found {} course(s)", courses.size());
        return ResponseEntity.ok(courses);
    }

    /**
     * Handle HTTP GET to fetch upcoming courses.
     * - Log the request to fetch upcoming courses.
     * - Call service to retrieve upcoming courses.
     * - If no upcoming courses found:
     *   - Log a warning.
     *   - Return 404 with message: "No upcoming courses found"
     * - Else:
     *   - Log how many upcoming courses were found.
     *   - Return HTTP 200 with list of upcoming courses.
     */
    @GetMapping("/upcoming")
    public ResponseEntity<?> getUpcomingCourses() {
        logger.info("GET /api/courses/upcoming - Fetching upcoming courses");
        List<Course> upcomingCourses = courseService.getUpcomingCourses();
        
        if (upcomingCourses == null || upcomingCourses.isEmpty()) {
            logger.warn("No upcoming courses found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No upcoming courses found");
        }
        
        logger.info("Found {} upcoming course(s)", upcomingCourses.size());
        return ResponseEntity.ok(upcomingCourses);
    }

    /**
     * Handle HTTP GET to fetch course by ID.
     * - Log the request with the given ID.
     * - Call service to retrieve the course by ID.
     * - If course not found:
     *   - Log a warning.
     *   - Return 404 with message: "Course not found"
     * - Else:
     *   - Log success.
     *   - Return HTTP 200 with the course.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getCourseById(@PathVariable Long id) {
        logger.info("GET /api/courses/{} - Fetching course with ID {}", id, id);
        try {
            Course course = courseService.getCourseById(id);
            logger.info("Found course with ID {}", id);
            return ResponseEntity.ok(course);
        } catch (RuntimeException e) {
            logger.warn("Course not found with ID {}", id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Course not found");
        }
    }
}