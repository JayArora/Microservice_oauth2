package com.enrollment.courseservice.service;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.enrollment.courseservice.entity.Category;
import com.enrollment.courseservice.entity.Course;
import com.enrollment.courseservice.repository.CategoryRepository;
import com.enrollment.courseservice.repository.CourseRepository;

@Service
public class CourseService {

    private static final Logger logger = LoggerFactory.getLogger(CourseService.class);

    private final CourseRepository courseRepository;
    private final CategoryRepository categoryRepository;

    // Constructor injection for dependencies
    public CourseService(CourseRepository courseRepository, CategoryRepository categoryRepository) {
        this.courseRepository = courseRepository;
        this.categoryRepository = categoryRepository;
    }

    /**
     * Create a new course with categories.
     * - Log course creation
     * - Check if categories exist in DB, otherwise save them
     * - Attach categories to course
     * - Save course into DB
     */
    @Transactional
    public Course createCourse(Course course) {
        logger.info("Creating a new course with title: {}", course.getTitle());

        if (course.getCategories() != null && !course.getCategories().isEmpty()) {
            Set<Category> persistedCategories = new HashSet<>();
            
            for (Category category : course.getCategories()) {
                // Check if the category already exists by name to prevent duplicates
                Optional<Category> existingCategory = categoryRepository.findByName(category.getName());
                
                if (existingCategory.isPresent()) {
                    persistedCategories.add(existingCategory.get());
                } else {
                    logger.debug("Category '{}' not found, creating a new record.", category.getName());
                    persistedCategories.add(categoryRepository.save(category));
                }
            }
            // Attach the managed/saved categories to the course entity
            course.setCategories(persistedCategories);
        }

        return courseRepository.save(course);
    }

    /**
     * Fetch all courses from DB
     * - Log request
     */
    @Transactional(readOnly = true)
    public List<Course> getAllCourses() {
        logger.info("Fetching all courses from the database");
        return courseRepository.findAll();
    }

    /**
     * Fetch active courses
     * - Active = courses running on current date (startDate <= today <= endDate)
     */
    @Transactional(readOnly = true)
    public List<Course> getActiveCourses() {
        LocalDate today = LocalDate.now();
        logger.info("Fetching active courses running on date: {}", today);
        return courseRepository.findByStartDateLessThanEqualAndEndDateGreaterThanEqual(today, today);
       // return courseRepository.findActiveCourses(today);
    }

    /**
     * Fetch upcoming courses (within next 30 days)
     * - Upcoming = courses where startDate is between tomorrow and today + 30 days
     */
    @Transactional(readOnly = true)
    public List<Course> getUpcomingCourses() {
        LocalDate today = LocalDate.now();
        LocalDate thirtyDaysFromNow = today.plusDays(30);
        logger.info("Fetching upcoming courses starting between {} and {}", today.plusDays(1), thirtyDaysFromNow);
        return courseRepository.findByStartDateBetween(today.plusDays(1), thirtyDaysFromNow);
    }

    /**
     * Fetch course by ID
     * - Return course if found
     * - Log warning if not found
     */
    @Transactional(readOnly = true)
    public Course getCourseById(Long id) {
        logger.info("Fetching course with ID: {}", id);
        return courseRepository.findById(id)
                .orElseThrow(() -> {
                    logger.warn("Course with ID {} was not found", id);
                    return new RuntimeException("Course not found with id: " + id);
                });
    }
}