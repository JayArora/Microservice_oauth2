package com.enrollment.courseservice.DTO;

public class LoginRequest {
    private String username;
    private String password;
    // Getters, Setters, Constructors
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
    
}