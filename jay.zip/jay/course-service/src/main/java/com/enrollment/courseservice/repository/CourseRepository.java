package com.enrollment.courseservice.repository;

import com.enrollment.courseservice.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.time.LocalDate;
import java.util.List;

public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findByStartDateBetween(LocalDate start, LocalDate end);

    @Query(value = "SELECT c.name as category, COUNT(cc.course_id) as cnt FROM categories c LEFT JOIN course_category cc ON c.id = cc.category_id GROUP BY c.name", nativeQuery = true)
    List<Object[]> countCoursesByCategoryNative();

    @Query("SELECT c FROM Course c WHERE c.startDate <= :date AND c.endDate >= :date")
    List<Course> findActiveCourses(LocalDate date);

	List<Course> findByStartDateLessThanEqualAndEndDateGreaterThanEqual(LocalDate today, LocalDate today2);
}
