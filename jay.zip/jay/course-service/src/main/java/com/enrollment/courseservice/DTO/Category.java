package com.enrollment.courseservice.DTO;

import com.enrollment.courseservice.entity.Course;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.util.HashSet;
import java.util.Set;

public class Category {
    private Long id;
    private String name;
    private Set<Course> courses = new HashSet<>();

    public Category(){}

    //TODO:Create the getters and setters

}
