package com.enrollment.courseservice.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enrollment.courseservice.DTO.LoginRequest;
// FIXED: Added missing import for your token provider component
import com.enrollment.courseservice.security.JwtTokenProvider;
// FIXED: Adjusted package reference to match standard lowercase package naming if applicable

@RestController 
@RequestMapping("/auth") 
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider; 

    // Constructor injection for clean architecture and easy testing
    public AuthController(AuthenticationManager authenticationManager, JwtTokenProvider jwtTokenProvider) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    /**
     * Handle HTTP POST to user login and JWT token generation.
     */
    @PostMapping("/login") 
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        logger.info("Entered Login Method");

        try {
            // Authenticate user using AuthenticationManager with username & password
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getUsername(), 
                            loginRequest.getPassword()
                    )
            );

            // Extract user identity parameters from authentication token
            String username = authentication.getName();
            String roles = authentication.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.joining(","));

            // Generate verified JWT token using username and roles mapping
            String jwtToken = jwtTokenProvider.generateToken(username, roles);
            
            logger.info("Login successful for user: {}", username);

            // Return HTTP 200 with the authorization token payload
            Map<String, String> responseBody = new HashMap<>();
            responseBody.put("token", jwtToken);
            
            return ResponseEntity.ok(responseBody);

        } catch (AuthenticationException e) {
            logger.error("Authentication failed: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid User Credential");
        }
    }
}