package com.enrollment.studentservice.service;

import com.enrollment.studentservice.client.CourseClient;
import com.enrollment.studentservice.exception.StudentAlreadyExistsException;
import com.enrollment.studentservice.exception.StudentNotFoundException;
import com.enrollment.studentservice.model.Student;
import com.enrollment.studentservice.repository.StudentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StudentService {

    private static final Logger logger = LoggerFactory.getLogger(StudentService.class);

    private final StudentRepository repository;
    private final CourseClient courseClient;

    // Constructor injection for required infrastructure dependencies
    public StudentService(StudentRepository repository, CourseClient courseClient) {
        this.repository = repository;
        this.courseClient = courseClient;
    }

    /**
     * Save a new student.
     * - Log the student email
     * - Save using repository
     */
    @Transactional
    public Student save(Student student) {
        logger.info("Attempting to save student with email: {}", student.getEmail());
        return repository.save(student);
    }

    /**
     * Find a student by ID.
     * - If not found → throw StudentNotFoundException
     */
    @Transactional(readOnly = true)
    public Student findById(Long id) {
        logger.debug("Finding student details by ID: {}", id);
        return repository.findById(id)
                .orElseThrow(() -> new StudentNotFoundException("Student not found with ID: " + id));
    }

    /**
     * Enroll a student in a course.
     * - Fetch student by ID (throw exception if not found)
     * - If already enrolled → throw StudentAlreadyExistsException
     * - Else add courseId to student’s enrolledCourseIds
     * - Save updated student
     */
    @Transactional
    public Student enrollInCourse(Long studentId, Long courseId) {
        logger.info("Processing course enrollment request for student ID: {} into course ID: {}", studentId, courseId);
        
        // 1. Fetch student by ID (automatically leverages findById logic/exception)
        Student student = findById(studentId);

        // Optional Validation: If you want to use the courseClient to check if the course exists before enrolling
        // logger.debug("Verifying course existence via OpenFeign client for course ID: {}", courseId);
        // courseClient.getCourseById(courseId); 

        // 2. Verify enrollment exclusivity to prevent duplicates
        if (student.getEnrolledCourseIds().contains(courseId)) {
            logger.warn("Enrollment failed: Student {} is already enrolled in course {}", studentId, courseId);
            throw new StudentAlreadyExistsException("Student is already enrolled in course with ID: " + courseId);
        }

        // 3. Update the tracking collection values
        student.getEnrolledCourseIds().add(courseId);
        logger.info("Successfully added course ID {} to student payload. Persisting modifications...", courseId);

        // 4. Save and return the transactional resource state
        return repository.save(student);
    }
}