package com.enrollment.studentservice.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body){
        String username = body.getOrDefault("username","user");
        return ResponseEntity.ok(Map.of("token","dummy-token-for-"+username));
    }
}
