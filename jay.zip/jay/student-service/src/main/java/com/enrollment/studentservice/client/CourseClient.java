package com.enrollment.studentservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.http.ResponseEntity;

import java.util.List;

@FeignClient(name = "course-service")
public interface CourseClient {

    @GetMapping("/api/courses/{id}")
    ResponseEntity<CourseDTO> getCourse(@RequestHeader("Authorization") String token,
                                        @PathVariable("id") Long id);

    @GetMapping("/api/courses/upcoming")
    ResponseEntity<List<CourseDTO>> getUpcomingCourses(@RequestHeader("Authorization") String token);

    @GetMapping("/api/courses")
    ResponseEntity<List<CourseDTO>> getAllCourses(@RequestHeader("Authorization") String token);
}
