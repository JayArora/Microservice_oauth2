package com.enrollment.studentservice.client;

import java.time.LocalDate;
import java.util.Set;

public class CourseDTO {
    private Long id;
    private String title;
    private String description;
    private LocalDate startDate;

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
}
