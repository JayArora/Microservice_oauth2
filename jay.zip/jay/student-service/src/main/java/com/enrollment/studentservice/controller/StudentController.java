package com.enrollment.studentservice.controller;

import com.enrollment.studentservice.client.CourseClient;
import com.enrollment.studentservice.client.CourseDTO;
import com.enrollment.studentservice.model.Student;
import com.enrollment.studentservice.service.StudentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService studentService;
    private final CourseClient courseClient;

    private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

    // Constructor injection for StudentService and CourseClient
    public StudentController(StudentService studentService, CourseClient courseClient) {
        this.studentService = studentService;
        this.courseClient = courseClient;
    }

    /**
     * Handle HTTP POST to create a new student.
     * - Log student email
     * - Call StudentService to save student
     * - Return HTTP 201 with created student
     * - If error occurs, log error and return 500 with error message
     */
    @PostMapping
    public ResponseEntity<?> createStudent(@RequestBody Student student) {
        logger.info("Received request to create student with email: {}", student.getEmail());
        try {
            Student savedStudent = studentService.save(student);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedStudent);
        } catch (Exception e) {
            logger.error("Failed to create student: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error creating student: " + e.getMessage());
        }
    }

    /**
     * Handle HTTP PUT to enroll a student in a course.
     * - Log request details (studentId, courseId)
     * - Call StudentService to enroll student
     * - Return HTTP 200 with updated student object
     */
    @PutMapping("/{id}/enroll/{courseId}")
    public ResponseEntity<Student> enrollStudent(@PathVariable Long id, @PathVariable Long courseId) {
        logger.info("Received request to enroll student ID: {} into course ID: {}", id, courseId);
        Student updatedStudent = studentService.enrollInCourse(id, courseId);
        return ResponseEntity.ok(updatedStudent);
    }

    /**
     * Handle HTTP GET to fetch a student by ID.
     * - Log request
     * - If student not found → return 404 with message
     * - Else → return 200 with student details
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getStudentById(@PathVariable Long id) {
        logger.info("Received request to fetch student details for ID: {}", id);
        try {
            Student student = studentService.findById(id);
            return ResponseEntity.ok(student);
        } catch (Exception e) {
            logger.warn("Student not found for ID: {}. Message: {}", id, e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    /**
     * Test Feign client communication with Course Service.
     * - Send request via CourseClient
     * - Extract "X-Instance-Port" header
     * - Return list of courses with header
     * - If error → return 500 with details
     */
    @GetMapping("/test-feign-courses")
    public ResponseEntity<?> testFeignCourses(@RequestHeader("Authorization") String token) {
        logger.info("Testing communication to Course Service using Feign client");
        try {
            // Send the Authorization token down to downstream microservices through feign exchange
            ResponseEntity<List<CourseDTO>> feignResponse = courseClient.getAllCourses(token);
            
            List<CourseDTO> courses = feignResponse.getBody();
            String portHeader = feignResponse.getHeaders().getFirst("X-Instance-Port");
            
            logger.info("Successfully fetched courses via Feign. Downstream server port header captured: {}", portHeader);

            // Constructing an envelope to return both dataset and internal tracking port header value
            return ResponseEntity.ok(Map.of(
                "courses", courses != null ? courses : List.of(),
                "handledByPort", portHeader != null ? portHeader : "Unknown"
            ));
        } catch (Exception e) {
            logger.error("Feign call to course-service dropped or failed: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Feign communication failure: " + e.getMessage());
        }
    }
}